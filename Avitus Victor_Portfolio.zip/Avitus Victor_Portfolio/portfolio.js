
<i class="fas fa-star" onmouseover="highlightIcon(this)" onmouseout="removeHighlight(this)"></i>

script>
    function highlightIcon(icon) {
        icon.style.color = 'gold';
    }

    function removeHighlight(icon) {
        icon.style.color = ''; 
    }
</script>
